import argparse
import gzip
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.linalg import eigh

LAYER_MAP = {"RT": "RT", "MT": "MT", "RE": "RE"}


def load_activity(path: Path) -> pd.DataFrame:
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8", errors="ignore") as f:
        df = pd.read_csv(
            f,
            sep=r"\s+",
            header=None,
            names=["timestamp", "source", "target", "interaction_type"],
        )
    df = df[df["interaction_type"].isin(LAYER_MAP)]
    df["datetime"] = pd.to_datetime(df["timestamp"], unit="s", utc=True)
    return df


def hourly_windows(df: pd.DataFrame, hours: int = 1):
    df = df.copy()
    df["window_start"] = df["datetime"].dt.floor(f"{hours}h")
    for window_start, part in df.groupby("window_start"):
        yield window_start, part


def density_from_edges(edges: pd.DataFrame) -> np.ndarray:
    nodes = pd.Index(sorted(set(edges["source"]).union(set(edges["target"]))))
    if len(nodes) == 0:
        return np.eye(1)
    idx = {n: i for i, n in enumerate(nodes)}
    a = np.zeros((len(nodes), len(nodes)), dtype=float)
    for row in edges.itertuples(index=False):
        i = idx[row.source]
        j = idx[row.target]
        a[i, j] += 1.0
        a[j, i] += 1.0
    trace = np.trace(a)
    if trace <= 0:
        trace = a.sum()
    if trace <= 0:
        return np.eye(max(1, len(nodes))) / max(1, len(nodes))
    return a / trace


def von_neumann_entropy(rho: np.ndarray) -> float:
    vals = np.clip(eigh(rho, eigvals_only=True), 0, None)
    vals = vals[vals > 1e-12]
    if len(vals) == 0:
        return 0.0
    return float(-(vals * np.log2(vals)).sum())


def qjsd(rho: np.ndarray, sigma: np.ndarray) -> float:
    dim = max(rho.shape[0], sigma.shape[0])
    rr = np.zeros((dim, dim))
    ss = np.zeros((dim, dim))
    rr[: rho.shape[0], : rho.shape[1]] = rho
    ss[: sigma.shape[0], : sigma.shape[1]] = sigma
    m = 0.5 * (rr + ss)
    return float(von_neumann_entropy(m) - 0.5 * von_neumann_entropy(rr) - 0.5 * von_neumann_entropy(ss))


def fidelity_proxy(rho: np.ndarray, sigma: np.ndarray) -> float:
    dim = max(rho.shape[0], sigma.shape[0])
    rr = np.zeros((dim, dim))
    ss = np.zeros((dim, dim))
    rr[: rho.shape[0], : rho.shape[1]] = rho
    ss[: sigma.shape[0], : sigma.shape[1]] = sigma
    return float(np.sum(np.sqrt(np.clip(rr * ss, 0, None))))


def analyze(df: pd.DataFrame, window_hours: int):
    records = []
    prev_rho = None
    for t, part in hourly_windows(df, hours=window_hours):
        rho = density_from_edges(part[["source", "target"]])
        entropy = von_neumann_entropy(rho)
        div = qjsd(prev_rho, rho) if prev_rho is not None else 0.0
        fid = fidelity_proxy(prev_rho, rho) if prev_rho is not None else 1.0
        records.append({"window_start": t, "entropy": entropy, "qjsd": div, "fidelity": fid, "events": len(part)})
        prev_rho = rho
    out = pd.DataFrame(records)
    out["curvature_proxy"] = out["qjsd"].diff().diff().fillna(0.0)
    return out


def plot_metrics(results: pd.DataFrame, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    for col in ["events", "entropy", "qjsd", "fidelity", "curvature_proxy"]:
        plt.figure(figsize=(10, 4))
        plt.plot(results["window_start"], results[col])
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(outdir / f"{col}.png", dpi=200)
        plt.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--window-hours", type=int, default=1)
    args = parser.parse_args()

    input_path = Path(args.input)
    processed_dir = Path("data/processed")
    figures_dir = Path("figures")
    processed_dir.mkdir(parents=True, exist_ok=True)

    df = load_activity(input_path)
    results = analyze(df, args.window_hours)
    results.to_csv(processed_dir / "window_metrics.csv", index=False)
    plot_metrics(results, figures_dir)
    print("Saved:", processed_dir / "window_metrics.csv")

